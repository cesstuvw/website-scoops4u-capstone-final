$('#btn-show').on('click', function(){
    $('#form-date').fadeToggle(1000)
    $('#form_textsearch').fadeToggle(1000)

})

