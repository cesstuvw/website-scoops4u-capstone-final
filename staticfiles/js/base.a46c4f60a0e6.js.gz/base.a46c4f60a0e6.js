$(document).ready(function(){


        $('#product').css('color', 'blue')
        $('#dashboard').css('color', 'red')


})

