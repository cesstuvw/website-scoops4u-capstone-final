$(document).ready(function(){
  
        var payment_id = $('#payment_id').val()
        $('#get_id').val(payment_id)

        // $('#btn-print').on('click', function (e) {
        //         window.print()
        //         $('#btn-receipt').removeClass("d-none");
                
        // })

        

})