$(document).ready(function(){


    $('#checkbox').on('click', function(){
        $('#btn_submit').fadeToggle(1000);
    })
    
})